-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2018 at 05:29 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloodbankregistration`
--

CREATE TABLE `bloodbankregistration` (
  `userName` varchar(30) NOT NULL,
  `bbName` varchar(3000) NOT NULL,
  `address` varchar(3000) NOT NULL,
  `email` varchar(3000) NOT NULL,
  `contact` varchar(3000) NOT NULL,
  `image` varchar(3000) NOT NULL,
  `password` varchar(3000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbankregistration`
--

INSERT INTO `bloodbankregistration` (`userName`, `bbName`, `address`, `email`, `contact`, `image`, `password`) VALUES
('jhjhgfk', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfk_1.jpg', 'jhjhgfh'),
('g', '', 'g', 'g', 'g', 'g_1.jpg', 'f'),
('heh', '', 'h', 'h', 'h', 'heh_1.jpg', 'h'),
('hehh', '', 'h', 'h', 'h', 'hehh_1.jpg', 'h'),
('hehhhhv', 'h', 'h', 'h', 'h', 'hehhhhv_1.jpg', 'h'),
('jbb', 'Jinja Blood Bank', 'Kampala', 'jbb@gmail.com', '070448877', 'jbb_1.jpg', 'p'),
('mbb', 'Mulago Blood Bank', 'mulago, wandegeya, Kampala', 'mbb@gmail.com', '07123', 'mbb_1.jpg', 'p'),
('wbb', 'Wakiso Blood Bank', 'kazo, Wakiso, Uganda', 'wbb@gmail.com', '07123', 'wbb_1.jpg', 'pw'),
('SBB', 'Small Blood Bank', 'mulagi', 'small@gmail.com', '789', 'SBB_1.jpg', 'sbb');

-- --------------------------------------------------------

--
-- Table structure for table `blood_bank_quantity`
--

CREATE TABLE `blood_bank_quantity` (
  `id` int(10) NOT NULL,
  `userName` varchar(100) NOT NULL,
  `o_` varchar(100) DEFAULT '0',
  `o` varchar(100) DEFAULT '0',
  `a_` varchar(100) DEFAULT '0',
  `a` varchar(100) DEFAULT '0',
  `b_` varchar(100) DEFAULT '0',
  `b` varchar(100) DEFAULT '0',
  `ab_` varchar(100) DEFAULT '0',
  `ab` varchar(100) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_bank_quantity`
--

INSERT INTO `blood_bank_quantity` (`id`, `userName`, `o_`, `o`, `a_`, `a`, `b_`, `b`, `ab_`, `ab`) VALUES
(1, 'jbb', '1', '2', '3', '4', '5', '6', '7', '8'),
(5, 'wbb', '0', '0', '0', '0', '0', '0', '0', '0'),
(4, 'mbb', '0', '0', '0', '0', '0', '0', '0', '0'),
(6, 'SBB', '0', '0', '0', '0', '0', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `blood_pack`
--

CREATE TABLE `blood_pack` (
  `id` int(10) NOT NULL,
  `packNumber` varchar(30) NOT NULL,
  `bloodBank` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_pack`
--

INSERT INTO `blood_pack` (`id`, `packNumber`, `bloodBank`) VALUES
(9, 'M000123', 'JBB'),
(19, 'A111', 'JBB');

-- --------------------------------------------------------

--
-- Table structure for table `centernotifications`
--

CREATE TABLE `centernotifications` (
  `notificationID` int(10) NOT NULL,
  `today` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bloodCenter` varchar(3000) NOT NULL,
  `date` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` varchar(3000) NOT NULL,
  `link` varchar(5000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `centernotifications`
--

INSERT INTO `centernotifications` (`notificationID`, `today`, `bloodCenter`, `date`, `title`, `message`, `link`) VALUES
(4, '2018-04-21 10:37:13', 'Jinja Blood Bank', '21/4/2018', 'xcancer blood drive : KK Village ', 'u two can give life to some one even if u dont have money to buy there medicine, Sharing your blood could be a way. Come 4 blood donation a kkm village tomorrow', 'http://g.com/google'),
(3, '2018-04-21 10:03:45', 'Jinja Blood Bank', '21/4/2018', 'title', 'message', 'link');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `userName` varchar(300) NOT NULL,
  `fullNames` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `contact` varchar(130) NOT NULL,
  `village` varchar(300) NOT NULL,
  `city` varchar(30) NOT NULL,
  `specialID` int(100) NOT NULL,
  `gender` varchar(300) NOT NULL,
  `bloodType` varchar(30) NOT NULL,
  `doB` varchar(20) NOT NULL,
  `image` text NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`userName`, `fullNames`, `email`, `contact`, `village`, `city`, `specialID`, `gender`, `bloodType`, `doB`, `image`, `password`) VALUES
('nsimbi', 'kato paul', 'nsimbiivan@gmail.com', '07857468', 'kajjansi', 'Entebbe', 7, 'Male', 'B-', '25/4/2018', 'nsimbi_1.jpg', 'fg'),
('izo', 'Isaac Balintuma ', 'isaaconline96@gmail.com', '0704873305', 'Gayaza', 'Wakiso', 9, 'Male', 'B-', '6/6/1996', 'izo_1.jpg', '123'),
('tj', 'Teberyowa Justine', 'tj@gmail.com', '0750313260', 'maya', 'masaka', 15, 'Female', 'A+', '12/1/1995', 'tj_1.jpg', 'tb'),
('mc', 'Micheal Omara', 'michealomara21@gmail.com', '0785', 'kawempe', 'Kampala', 22, 'Male', 'B-', '17/6/1996', 'mc_1.jpg', 'cv');

-- --------------------------------------------------------

--
-- Table structure for table `donorpoints`
--

CREATE TABLE `donorpoints` (
  `id` int(10) NOT NULL,
  `userName` varchar(100) NOT NULL,
  `Xvalue` int(10) NOT NULL,
  `Zvalue` int(10) NOT NULL,
  `points` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donorpoints`
--

INSERT INTO `donorpoints` (`id`, `userName`, `Xvalue`, `Zvalue`, `points`) VALUES
(1, 'izo', 7, 6, 56000),
(4, 'nsimbi', 2, 0, 3124),
(6, 'h', 0, 0, 0),
(7, 'hh', 0, 0, 0),
(8, 'tj', 0, 0, 2),
(9, 'm', 0, 0, 0),
(10, 'jj', 0, 0, 0),
(11, 'hl', 0, 0, 0),
(12, 'j', 0, 0, 0),
(13, 'mj', 0, 0, 4),
(14, 'mike', 0, 0, 0),
(15, 'mc', 0, 0, 0),
(16, 'mcf', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hospitalemergency`
--

CREATE TABLE `hospitalemergency` (
  `emergencyID` int(10) NOT NULL,
  `hospitalName` varchar(300) NOT NULL,
  `date` varchar(20) NOT NULL,
  `title` varchar(300) NOT NULL,
  `message` varchar(3000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitalemergency`
--

INSERT INTO `hospitalemergency` (`emergencyID`, `hospitalName`, `date`, `title`, `message`) VALUES
(1, 'mulago', '09/09/2009', 'blood group 0-', 'come donate'),
(2, 'Manyangwa hospital', '', 'title', 'message'),
(3, 'Manyangwa hospital', '22/4/2018', 'j', 'j'),
(4, 'Manyangwa hospital', '22/4/2018', 'jtyyy', 'jtgg'),
(5, 'Manyangwa hospital', '22/4/2018', 'jtyyy', 'jtgg'),
(6, 'Manyangwa hospital', '16/5/2018', 'title', 'message'),
(7, 'Manyangwa hospital', '22/4/2018', 'New Disease : HIV HPC disease', 'as per now this disease has killed 1020 people in the whole of Uganda , it is commonly reported in areas with lots of waters, youth and sex');

-- --------------------------------------------------------

--
-- Table structure for table `hospitalsignup`
--

CREATE TABLE `hospitalsignup` (
  `userName` varchar(30) NOT NULL,
  `hospitalName` varchar(3000) NOT NULL,
  `address` varchar(3000) NOT NULL,
  `email` varchar(3000) NOT NULL,
  `contact` varchar(3000) NOT NULL,
  `image` varchar(2000) NOT NULL,
  `password` varchar(30000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitalsignup`
--

INSERT INTO `hospitalsignup` (`userName`, `hospitalName`, `address`, `email`, `contact`, `image`, `password`) VALUES
('BH', 'Black Hospital', 'Gayaza Naalya', 'asdg', '977', 'BH_1.jpg', 'bh'),
('isaac', 'man', 'mose', 'hhd', 'hh', 'isaac_1.jpg', 'pwd'),
('mh', 'Manyangwa hospital', 'Manyangwa - Naalya road', 'mh@gmail.com', '087', 'mh_1.jpg', 'p');

-- --------------------------------------------------------

--
-- Table structure for table `ratioofpeoplewithbloodtype`
--

CREATE TABLE `ratioofpeoplewithbloodtype` (
  `id` int(10) NOT NULL,
  `a` varchar(10) NOT NULL,
  `a_` varchar(10) NOT NULL,
  `b` varchar(10) NOT NULL,
  `b_` varchar(10) NOT NULL,
  `ab` varchar(10) NOT NULL,
  `ab_` varchar(10) NOT NULL,
  `o` varchar(10) NOT NULL,
  `o_` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratioofpeoplewithbloodtype`
--

INSERT INTO `ratioofpeoplewithbloodtype` (`id`, `a`, `a_`, `b`, `b_`, `ab`, `ab_`, `o`, `o_`) VALUES
(1, '0.7', '0.4', '0.9', '0.5', '0.5', '4.0', '2.5', '0.5');

-- --------------------------------------------------------

--
-- Table structure for table `rewards`
--

CREATE TABLE `rewards` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `points` int(30) NOT NULL,
  `quantity` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rewards`
--

INSERT INTO `rewards` (`id`, `image`, `name`, `description`, `points`, `quantity`) VALUES
(1, 'samsung_65_4K_tv.jpg', 'SamSung Flat Screen TV', 'Its a 65 inches Flat Screen TV with a 4K Screen display that costs around 13 Million Uganda Shillings', 150000, '19'),
(2, 'dell_laptop_xps_5th_i5.jpeg', 'Dell i5 Laptop', 'Amazingly This is a Dell portable i5 laptop with a 13 inch Screen and belonging to the 5th Generation produced in 2017', 10000, '10'),
(3, 'hackers_shirt.jpg', 'Hacker\'s Shirt', 'Its a black shirt with the words - Hackers gonna hack', 400, '1196');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloodbankregistration`
--
ALTER TABLE `bloodbankregistration`
  ADD PRIMARY KEY (`userName`);

--
-- Indexes for table `blood_bank_quantity`
--
ALTER TABLE `blood_bank_quantity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blood_pack`
--
ALTER TABLE `blood_pack`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `centernotifications`
--
ALTER TABLE `centernotifications`
  ADD PRIMARY KEY (`notificationID`);

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`specialID`),
  ADD UNIQUE KEY `userName` (`userName`);

--
-- Indexes for table `donorpoints`
--
ALTER TABLE `donorpoints`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userName` (`userName`);

--
-- Indexes for table `hospitalemergency`
--
ALTER TABLE `hospitalemergency`
  ADD PRIMARY KEY (`emergencyID`);

--
-- Indexes for table `hospitalsignup`
--
ALTER TABLE `hospitalsignup`
  ADD PRIMARY KEY (`userName`);

--
-- Indexes for table `ratioofpeoplewithbloodtype`
--
ALTER TABLE `ratioofpeoplewithbloodtype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rewards`
--
ALTER TABLE `rewards`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blood_bank_quantity`
--
ALTER TABLE `blood_bank_quantity`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `blood_pack`
--
ALTER TABLE `blood_pack`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `centernotifications`
--
ALTER TABLE `centernotifications`
  MODIFY `notificationID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `specialID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `donorpoints`
--
ALTER TABLE `donorpoints`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `hospitalemergency`
--
ALTER TABLE `hospitalemergency`
  MODIFY `emergencyID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ratioofpeoplewithbloodtype`
--
ALTER TABLE `ratioofpeoplewithbloodtype`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `rewards`
--
ALTER TABLE `rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
