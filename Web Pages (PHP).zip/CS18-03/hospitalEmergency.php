<?php

 $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
	$dbname= "project";

// Create connection
$conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

/*$hospitalName = $_POST['hospitalName'];
$date= $_POST['date'];
$title =$_POST['title'];
$message = $_POST['message'];
$link = $_POST['link'];*/

$hospitalName = "mulago";
$date= "09/09/2009";
$title ="blood group 0-";
$message = "come donate";
$link = "fgdfgdfgdfgdfgd/fgfd/g/fg";

$ft = "insert into hospitalEmergency (hospitalName, date, title, message,link) 
values ('$hospitalName', '$date', '$title', '$message', '$link')";

if ($conn->query($ft) === TRUE) {
	echo "Emergency successfully logged";  
} else {
    echo "Error: " . $ft . "<br>" . $conn->error;
}

$conn->close();
?>