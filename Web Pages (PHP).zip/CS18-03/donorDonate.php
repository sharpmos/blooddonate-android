<?php

require "donorCalcPoints.php";

 $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
	$dbname= "project";

// Create connection
$conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


		$packNumber = $_POST['packNumber'];
		$userName = $_POST['userName'];
		$userBloodType = $_POST['userBloodType'];


		$qry1 ="SELECT * FROM blood_pack where  packNumber='$packNumber' ";
		$response = mysqli_query($conn,$qry1);
			
        $database_array = array();
        while ( $row = mysqli_fetch_assoc($response) ) {
            array_push($database_array, $row);
        }   



		if (sizeof($database_array)==0 ) {
			echo "NOT_FOUND";
		}else{

			//DELETE THE INPUT PACK NUMBER FROM THE AVAILABLE PACKS
			$qry2 = "DELETE FROM blood_pack WHERE packNumber='$packNumber' ";
			$response = mysqli_query($conn,$qry2);

			//GET AND UPDATE THE VALUE IN X IN donorpoints TABLE 
			$qry3 ="SELECT * FROM donorpoints where  userName='$userName' ";
			$response = mysqli_query($conn,$qry3);
			$row = mysqli_fetch_assoc($response);
			$Xvalue = $row["Xvalue"];

			$XvalueNew = $Xvalue+1;

			$updateXvalue = "UPDATE `donorpoints` SET `Xvalue` = '$XvalueNew' WHERE `donorpoints`.`userName` = '$userName';";
			$response = mysqli_query($conn,$updateXvalue);




			//EVALUATE NEW POINTS USING THE MATHEMATICAL MODEL AND RETURN IT TO APP
			echo calculateCurrentDonorPoints($userName,$userBloodType);
		}






















$conn->close();
?>