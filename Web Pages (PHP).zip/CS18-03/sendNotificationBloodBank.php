<?php

 $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
	$dbname= "project";

// Create connection
$conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$bloodCenter = $_POST['bloodCenterName'];
$date= $_POST['dob'];
$title =$_POST['title'];
$message = $_POST['message'];
$link = $_POST['link'];

// $bloodCenter = "jinja blood bank";
// $date= "09/09/2009";
// $title ="blood group 0-";
// $message = "come donate";
// $link = "fgdfgdfgdfgdfgd/fgfd/g/fg";

$ft = "insert into centerNotifications (bloodCenter, date, title, message,link) 
values ('$bloodCenter', '$date', '$title', '$message', '$link')";

if ($conn->query($ft) === TRUE) {
	echo "Notification successfully logged";  
} else {
    echo "Error: " . $ft . "<br>" . $conn->error;
}

$conn->close();
?>