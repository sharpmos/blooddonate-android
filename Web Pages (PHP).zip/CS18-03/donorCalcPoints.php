<?php  



$database_name = "project";
$host = "localhost";
$user_name = "root";
$password = "";

$link = mysqli_connect($host,$user_name,$password,$database_name);



function sortReverseReturn($data){
	asort($data);

	$dataValues = array();
	$i = 0;
	foreach ($data as $key => $value) {
		$dataValues[$i++] = $value;
	}
	

	$i1 = 0;
	foreach ($data as $key => $value) {
		$data[$key] = $dataValues[count($dataValues) - $i1++ - 1];
	}
	
	return $data;

}


function calculateCurrentDonorPoints($userName , $userBloodType){


	global $database_name;
	global $host;
	global $password;
	global $link;

	/*
		L = loyality points
		S = Number of donations made
		Y = Ratio of people with blood type
		Z = Recomandations 
	*/

	$qry1 ="SELECT * FROM donorpoints where userName='$userName' ";
	$response = mysqli_query($link,$qry1);
	$row = mysqli_fetch_assoc($response);

	$Xvalue = $row['Xvalue'];
	$Zvalue = $row['Zvalue'];
	$Points = $row['points'];

	$Z = $Zvalue;
	$X = $Xvalue;

	


	 //CALCULATING THE RATIO AND CHANGING THE ORDER OF THE ITEMS IN THE ARRAY

	$qry2 ="SELECT * FROM ratioofpeoplewithbloodtype";
	$response2 = mysqli_query($link,$qry2);
	$row2 = mysqli_fetch_assoc($response2);
	
	$RatioPeople = array(
		'a' => $row2['a'] , 
		'a_' => $row2['a_'] , 
		'b' => $row2['b'] , 
		'b_' => $row2['b_'] , 
		'o' => $row2['o'] , 
		'o_' => $row2['o_'] , 
		'ab' => $row2['ab'] , 
		'ab_' => $row2['ab_'] );

	$RatioPeople = sortReverseReturn($RatioPeople);
	
	$Y = $RatioPeople[$userBloodType];



	//CALCULATING THE AMOUNT OF BLOOD , SORTING IT AND REVERSING IT

	$quantityA = 0;
	$quantityA_ = 0;
	$quantityB = 0;
	$quantityB_ = 0;
	$quantityAB = 0;
	$quantityAB_ = 0;
	$quantityO = 0;
	$quantityO_ = 0;

	$qry3 ="SELECT * FROM blood_bank_quantity";
	$response3 = mysqli_query($link,$qry3);

	while ( $row3 = mysqli_fetch_assoc($response3) ) {	
		$quantityA 		= $quantityA + $row3['a'];
		$quantityA_ 	+= $row3['a_'];
		$quantityB 		+= $row3['b'];
		$quantityB_ 	+= $row3['b_'];
		$quantityAB 	+= $row3['ab'];
		$quantityAB_ 	+= $row3['ab_'];
		$quantityO 		+= $row3['o'];
		$quantityO_ 	+= $row3['o_'];
	}

	$quantityTotal = $quantityA 	+ 
					$quantityA_ 	+ 
					$quantityB 		+ 
					$quantityB_ 	+ 
					$quantityAB 	+ 
					$quantityAB_ 	+ 
					$quantityO 		+
					$quantityO_ ;

	$RatioBlood = array(
		'a' => $quantityA/$quantityTotal , 
		'a_' => $quantityA_/$quantityTotal , 
		'b' => $quantityB/$quantityTotal , 
		'b_' => $quantityB_/$quantityTotal , 
		'o' => $quantityO/$quantityTotal , 
		'o_' => $quantityO_/$quantityTotal, 
		'ab' => $quantityAB/$quantityTotal, 
		'ab_' => $quantityAB_/$quantityTotal 
	);

	$RatioBlood = sortReverseReturn($RatioBlood);
	$S = $RatioBlood[$userBloodType]*100;


	//COMPUTE POINTS FROM THE CURRENT STATE OF THE USER ----------------------------------------------
	$L = (int)( (2*$X) + 5*($S+$Y) + (3*$Z) );

	$newPoints = $Points + $L;
	$updateDonorR = "UPDATE `donorpoints` SET `points` = '$newPoints' WHERE `userName` = '$userName';";
	$response = mysqli_query($link,$updateDonorR);  

	//CLEAR ALL USED VALUES
	mysqli_query($link,"UPDATE `donorpoints` SET `Xvalue` = '0' WHERE `userName` = '$userName';");
	mysqli_query($link,"UPDATE `donorpoints` SET `Zvalue` = '0' WHERE `userName` = '$userName';");

	return $newPoints;
}


//echo calculateCurrentDonorPoints("izo","a_");


?>