<?php

 $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
	$dbname= "project";

// Create connection
$link = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
$conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//$user = "p";
$user = $_POST['userName'];
$name = $_POST['fName'];
$em = $_POST['email'];
$ctct =$_POST['donorContact'];
$vill = $_POST['donorVillage'];
$cit = $_POST['donorCity'];
$invitedBy = $_POST['invitedBy'];
//$sID = "090";
$sex = $_POST['sex'];
$bloodGroup= $_POST['bloodGroup'];
$dtOB =$_POST['dob'];
$img = str_replace(" ","_",$user). "_1.jpg";
$passw = $_POST['password'];
//$rePass = "POT09/;-rt67aa";

$ifp = fopen("image/".$img, 'wb');
fwrite($ifp, base64_decode($_POST['image']));
fclose($ifp);


$ft = "insert into donor (userName, fullNames, email, contact, village, city, gender, bloodType, doB, image, password) 
values ('$user', '$name', '$em', '$ctct', '$vill', '$cit', '$sex', '$bloodGroup', '$dtOB', '$img', '$passw')";

if ($conn->query($ft) === TRUE) {
    $ft2 = "insert into donorpoints (userName,Xvalue,Zvalue,points) values ('$user',0,0,50)";
    if ($conn->query($ft2) === TRUE) {
        
        if ($invitedBy != "") {
            //GET USERNAME FOR THE INVITOR
            $qry1 ="SELECT userName FROM donor where  specialID='$invitedBy' ";
            if($response = mysqli_query($link,$qry1)){
                $row = mysqli_fetch_assoc($response);
                $userName = $row["userName"];

                //GET INVITE POINTS
                $qry1 ="SELECT Zvalue FROM donorpoints where  donorpoints.userName='$userName' ";
                $response = mysqli_query($link,$qry1);
                $row = mysqli_fetch_assoc($response);
                $Zvalue = $row["Zvalue"];
                
                //UP DATE THE ZVALUE
                $Zvalue = $Zvalue + 1; 	
                $updateDonorZvalue = "UPDATE `donorpoints` SET `Zvalue` = '$Zvalue' WHERE `donorpoints`.`userName` = '$userName';";
                $response = mysqli_query($link,$updateDonorZvalue);  
            }
        }
        
        echo "1";
    }else {
        echo "0"; 
    } 
} else {
    echo "Error: " . $ft . "<br>" . $conn->error;
}

$conn->close();
?>