<?php  

	$database_name = "project";
	$host = "localhost";
	$user_name = "root";
	$password = "";

  $link = mysqli_connect($host,$user_name,$password,$database_name);
  
$bloodQuantity = $_POST['bloodQuantity'];
$bloodColumn = $_POST['bloodColumn'];
$bloodBankUserName = $_POST['bloodBankUserName'];
//$username = "g";
//$pass = "f";


$updateQuery = "UPDATE `blood_bank_quantity` SET `$bloodColumn` = '$bloodQuantity' WHERE `userName` = '$bloodBankUserName';";
$response = mysqli_query($link,$updateQuery);  

echo "OK";

?>