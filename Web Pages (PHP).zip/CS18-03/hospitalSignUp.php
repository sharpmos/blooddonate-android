<?php

 $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
	$dbname= "project";

// Create connection
$conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//$user = "p";
$user = $_POST['userName'];
$hName = $_POST['hospitalName'];
$hAddress = $_POST['address'];
$hemail = $_POST['email'];
$hContact =$_POST['contact'];
$hImage = str_replace(" ","_",$user). "_1.jpg";
$hPassword = $_POST['password'];

/*$user = "jhjhgfk";
$hName = "jhjhgfh";
$hAddress = "jhjhgfh";
$hemail = "jhjhgfh";
$hContact ="jhjhgfh";
$hImage = str_replace(" ","_",$user). "_1.jpg";
$hPassword = "jhjhgfh";*/



$ifp = fopen("image/".$hImage, 'wb');
fwrite($ifp, base64_decode($_POST['image']));
fclose($ifp);


$ft = "insert into hospitalSignUp(userName, hospitalName, address, email,contact, image, password) 
values ('$user', '$hName','$hAddress', '$hemail', '$hContact', '$hImage', '$hPassword')";

if ($conn->query($ft) === TRUE) {
	echo "1"; 
} else {
    echo "Error: " . $ft . "<br>" . $conn->error;
}

$conn->close();
?>