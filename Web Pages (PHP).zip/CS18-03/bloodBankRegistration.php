<?php

 $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
	$dbname= "project";

// Create connection
$conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//$user = "p";
$user = $_POST['userName'];
$bbName = $_POST['bbName'];
$bbAddress = $_POST['address'];
$bbemail = $_POST['email'];
$bbContact =$_POST['contact'];
$bbImage = str_replace(" ","_",$user). "_1.jpg";
$bbPassword = $_POST['password'];

/*$user = "jhjhgfk";
$bbName = "jhjhgfh";
$bbAddress = "jhjhgfh";
$bbemail = "jhjhgfh";
$bbContact ="jhjhgfh";
$bbImage = str_replace(" ","_",$user). "_1.jpg"; 
$bbPassword = "jhjhgfh";*/



$ifp = fopen("image/".$bbImage, 'wb');
fwrite($ifp, base64_decode($_POST['image']));
fclose($ifp);


$ft = "insert into bloodBankRegistration(userName, bbName, address, email,contact, image, password) 
values ('$user', '$bbName','$bbAddress', '$bbemail', '$bbContact', '$bbImage', '$bbPassword')";

if ($conn->query($ft) === TRUE) {

	$sq_blood_bank_quantity = "INSERT INTO `blood_bank_quantity` (`id`, `userName`, `o_`, `o`, `a_`, `a`, `b_`, `b`, `ab_`, `ab`) VALUES (NULL, '$user', '0', '0', '0', '0', '0', '0', '0', '0');";
	if ($conn->query($sq_blood_bank_quantity) === TRUE) {
		echo "1";
	}else{
		echo "0";
	}




} else {
    echo "Error: " . $ft . "<br>" . $conn->error;
}

$conn->close();
?>