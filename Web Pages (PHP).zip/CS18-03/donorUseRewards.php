<?php  

	$database_name = "project";
	$host = "localhost";
	$user_name = "root";
	$password = "";

  $link = mysqli_connect($host,$user_name,$password,$database_name);

  	 $userName = $_POST['userName'];
	 $rewardId = $_POST['rewardId'];


	//GET TOTAL POINTS OF THE CURRENT USER
	$qry1 ="SELECT * FROM donorpoints where  donorpoints.userName='$userName' ";
	$response = mysqli_query($link,$qry1);
	$row = mysqli_fetch_assoc($response);
	$userPoints = $row["points"];
	
	//GET TOTAL PRODUCT POINTS
	$qry2 ="SELECT * FROM rewards where  id='$rewardId' ";
	$response2 = mysqli_query($link,$qry2);
	$row2 = mysqli_fetch_assoc($response2);
	$rewardPoints = $row2["points"];
	$rewardQuantity = $row2["quantity"];

	$newUserPoints = $userPoints - $rewardPoints;
	$newRewardQuantity = $rewardQuantity - 1;



	
		//UPDATE USER POINTS  	
		$updateDonor = "UPDATE `donorpoints` SET `points` = '$newUserPoints' WHERE `donorpoints`.`userName` = '$userName';";
		mysqli_query($link,$updateDonor);
	
		//UPDATE QUANTITY  	
		$updateReward = "UPDATE `rewards` SET `quantity` = '$newRewardQuantity' WHERE `id` = '$rewardId';";
		mysqli_query($link,$updateReward);


		echo $newUserPoints.",".$newRewardQuantity;


/*
	if (mysqli_query($link,$updateDonor)) {
		echo "OKAY";
	}else{
		echo "WAAPI";
	}*/


?>