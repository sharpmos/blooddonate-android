<?php  

	$database_name = "makerere_hotspots";
	$host = "localhost";
	$user_name = "root";
	$password = "";

  $link = mysqli_connect($host,$user_name,$password,$database_name);

?>
WHERE userName = '$username' AND password = '$pass'