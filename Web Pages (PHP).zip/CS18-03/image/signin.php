<?php  

            $stud_no 	= $_POST['stud_no'];
			$pwd 		= $_POST['pwd'];

                require "connection.php";
				
				$database_array = array();
				
				$response = mysqli_query($link," 
													SELECT * 
													FROM student 
													WHERE stud_no = '$stud_no' AND pwd = '$pwd';
												");
							
                $database_array = array();

                while ( $row = mysqli_fetch_assoc($response) ) {
                  array_push($database_array, $row);
                }   

				echo json_encode($database_array);				

?>