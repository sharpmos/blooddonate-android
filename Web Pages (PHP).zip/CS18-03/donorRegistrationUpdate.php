<?php

 $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
	$dbname= "project";

// Create connection
$conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = $_POST['userName'];
$name = $_POST['fName'];
$em = $_POST['email'];
$ctct =$_POST['donorContact'];
$vill = $_POST['donorVillage'];
$cit = $_POST['donorCity'];
$sex = $_POST['sex'];
$bloodGroup= $_POST['bloodGroup'];
$dtOB =$_POST['dob'];
$img = str_replace(" ","_",$user). "_1.jpg";
$passw = $_POST['password'];

$ifp = fopen("image/".$img, 'wb');
fwrite($ifp, base64_decode($_POST['image']));
fclose($ifp);


$ft = "UPDATE donor
SET 
userName = '$user', 
fullNames = '$name', 
email = '$em', 
contact ='$ctct', 
village = '$vill',
city =  '$cit', 
gender = '$sex', 
bloodType = '$bloodGroup', 
doB = '$dtOB', 
image = '$img', 
password = '$passw'
WHERE userName = '$user'";

if ($conn->query($ft) === TRUE) {
	echo "Details Update successfully"; 
} else {
    echo "Error: " . $ft . "<br>" . $conn->error;
}

$conn->close();
?>