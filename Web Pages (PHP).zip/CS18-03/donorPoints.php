<?php

 $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
	$dbname= "project";

// Create connection
$conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

/*$userName = $_POST['userName'];
$Xvalue= $_POST['Xvalue'];
$Zvalue =$_POST['Zvalue'];
$Points = $_POST['Points'];
*/

$userName = "ffg";
$Xvalue= 6;
$Zvalue =5;
$Points = (2*$Xvalue) + (5*$Zvalue);


$ft = "insert into donorPoints (userName, Xvalue, Zvalue, Points) 
values ('$userName', '$Xvalue', '$Zvalue', '$Points')";

if ($conn->query($ft) === TRUE) {
	echo "Points Calculated";  
} else {
    echo "Error: " . $ft . "<br>" . $conn->error;
}

$conn->close();
?>