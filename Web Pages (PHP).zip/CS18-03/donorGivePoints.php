<?php  

	$database_name = "project";
	$host = "localhost";
	$user_name = "root";
	$password = "";

  $link = mysqli_connect($host,$user_name,$password,$database_name);

  	$userName = $_POST['userName'];
  	$userNameRecipient = $_POST['userNameRecipient'];
	$pointsGive = $_POST['pointsGive'];



	//GET THE POINTS OF THE RECIEPIENT
	$qry1 ="SELECT * FROM donorpoints where  donorpoints.userName='$userNameRecipient' ";
	$response = mysqli_query($link,$qry1);
	$row = mysqli_fetch_assoc($response);
	$recipientPoints = $row["points"];

	if($recipientPoints!=""){

		//MODIFY THE POINTS OF THE RECIEPIENT
		$recipientPointsN = $recipientPoints + $pointsGive;
		$updateDonorR = "UPDATE `donorpoints` SET `points` = '$recipientPointsN' WHERE `donorpoints`.`userName` = '$userNameRecipient';";
		$response = mysqli_query($link,$updateDonorR);  


		//GET TOTAL POINTS OF THE CURRENT USER
		$qry1 ="SELECT * FROM donorpoints where  donorpoints.userName='$userName' ";
		$response = mysqli_query($link,$qry1);
		$row = mysqli_fetch_assoc($response);
		$points = $row["points"];

		//SUBTRACT USER POINTS WITH WHAT HAS BEEN GIVEN OUT
		$newPoints = $points - $pointsGive; 	
		$updateDonor = "UPDATE `donorpoints` SET `points` = '$newPoints' WHERE `donorpoints`.`userName` = '$userName';";
		$response = mysqli_query($link,$updateDonor);  

		echo $newPoints;

	}else{
		echo "FAILED";
	}







/*
	if (mysqli_query($link,$updateDonor)) {
		echo "OKAY";
	}else{
		echo "WAAPI";
	}*/


?>