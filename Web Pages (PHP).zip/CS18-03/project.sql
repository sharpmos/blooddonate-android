-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2018 at 08:00 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloodbankregistration`
--

CREATE TABLE `bloodbankregistration` (
  `userName` varchar(30) NOT NULL,
  `bbName` varchar(3000) NOT NULL,
  `address` varchar(3000) NOT NULL,
  `email` varchar(3000) NOT NULL,
  `contact` varchar(3000) NOT NULL,
  `image` varchar(3000) NOT NULL,
  `password` varchar(3000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbankregistration`
--

INSERT INTO `bloodbankregistration` (`userName`, `bbName`, `address`, `email`, `contact`, `image`, `password`) VALUES
('jhjhgfk', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfk_1.jpg', 'jhjhgfh'),
('g', '', 'g', 'g', 'g', 'g_1.jpg', 'f'),
('heh', '', 'h', 'h', 'h', 'heh_1.jpg', 'h'),
('hehh', '', 'h', 'h', 'h', 'hehh_1.jpg', 'h'),
('hehhhhv', 'h', 'h', 'h', 'h', 'hehhhhv_1.jpg', 'h');

-- --------------------------------------------------------

--
-- Table structure for table `centernotifications`
--

CREATE TABLE `centernotifications` (
  `notificationID` int(10) NOT NULL,
  `bloodCenter` varchar(3000) NOT NULL,
  `date` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` varchar(3000) NOT NULL,
  `link` varchar(5000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `centernotifications`
--

INSERT INTO `centernotifications` (`notificationID`, `bloodCenter`, `date`, `title`, `message`, `link`) VALUES
(1, 'jinja blood bank', '09/09/2009', 'blood group 0-', 'come donate', 'fgdfgdfgdfgdfgd/fgfd/g/fg'),
(2, 'jinja blood bank', '09/09/2009', 'blood group 0-', 'come donate', 'fgdfgdfgdfgdfgd/fgfd/g/fg');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `userName` varchar(300) NOT NULL,
  `fullNames` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `contact` varchar(130) NOT NULL,
  `village` varchar(300) NOT NULL,
  `city` varchar(30) NOT NULL,
  `specialID` int(100) NOT NULL,
  `gender` varchar(300) NOT NULL,
  `bloodType` varchar(30) NOT NULL,
  `doB` varchar(20) NOT NULL,
  `image` text NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`userName`, `fullNames`, `email`, `contact`, `village`, `city`, `specialID`, `gender`, `bloodType`, `doB`, `image`, `password`) VALUES
('f', 't', '5', '5', 'r', 'r', 1, 'Male', 'A', '9/4/2018', 'f_1.png', 'd'),
('f g', 't', '5', '5', 'r', 'r', 2, 'Male', 'A', '9/4/2018', 'f g_1.png', 'd'),
('f gf', 't', '5', '5', 'r', 'r', 3, 'Male', 'A', '9/4/2018', 'f_gf_1.png', 'd'),
('fjg', 'g', 't', 't', 'y', 't', 4, 'Male', 'A', '9/4/2018', 'fjg_1.jpg', 'tu'),
('fjgfffg', 'g', 't', 't', 'y', 't', 5, 'Male', 'A', '9/4/2018', 'fjgfffg_1.jpg', 'tu'),
('ttttttt', 'yu', 'y', 'y', 'y', 'y', 6, 'Male', 'A', '3/4/2018', 'ttttttt_1.jpg', 'e'),
('nsimbi', 'kato paul', 'nsimbiivan@gmail.com', '07857468', 'kajjansi', 'Entebbe', 7, 'Male', 'B-', '25/4/2018', 'nsimbi_1.jpg', 'fg');

-- --------------------------------------------------------

--
-- Table structure for table `donorpoints`
--

CREATE TABLE `donorpoints` (
  `userName` varchar(3000) NOT NULL,
  `Xvalue` int(10) NOT NULL,
  `Zvalue` int(10) NOT NULL,
  `Points` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donorpoints`
--

INSERT INTO `donorpoints` (`userName`, `Xvalue`, `Zvalue`, `Points`) VALUES
('ffg', 6, 5, 37),
('ffg', 6, 5, 37),
('ffg', 6, 5, 37);

-- --------------------------------------------------------

--
-- Table structure for table `hospitalemergency`
--

CREATE TABLE `hospitalemergency` (
  `emergencyID` int(10) NOT NULL,
  `hospitalName` varchar(300) NOT NULL,
  `date` varchar(20) NOT NULL,
  `title` varchar(300) NOT NULL,
  `message` varchar(3000) NOT NULL,
  `link` varchar(5000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitalemergency`
--

INSERT INTO `hospitalemergency` (`emergencyID`, `hospitalName`, `date`, `title`, `message`, `link`) VALUES
(1, 'mulago', '09/09/2009', 'blood group 0-', 'come donate', 'fgdfgdfgdfgdfgd/fgfd/g/fg');

-- --------------------------------------------------------

--
-- Table structure for table `hospitalsignup`
--

CREATE TABLE `hospitalsignup` (
  `userName` varchar(30) NOT NULL,
  `hospitalName` varchar(3000) NOT NULL,
  `address` varchar(3000) NOT NULL,
  `email` varchar(3000) NOT NULL,
  `contact` varchar(3000) NOT NULL,
  `image` varchar(2000) NOT NULL,
  `password` varchar(30000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitalsignup`
--

INSERT INTO `hospitalsignup` (`userName`, `hospitalName`, `address`, `email`, `contact`, `image`, `password`) VALUES
('jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh_1.jpg', 'jhjhgfh'),
('jhjhgfk', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfh', 'jhjhgfk_1.jpg', 'jhjhgfh'),
('', '', '', '', '', '_1.jpg', 'pwd'),
('isaac', 'man', 'mose', 'hhd', 'hh', 'isaac_1.jpg', 'pwd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloodbankregistration`
--
ALTER TABLE `bloodbankregistration`
  ADD PRIMARY KEY (`userName`);

--
-- Indexes for table `centernotifications`
--
ALTER TABLE `centernotifications`
  ADD PRIMARY KEY (`notificationID`);

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`specialID`),
  ADD UNIQUE KEY `userName` (`userName`);

--
-- Indexes for table `hospitalemergency`
--
ALTER TABLE `hospitalemergency`
  ADD PRIMARY KEY (`emergencyID`);

--
-- Indexes for table `hospitalsignup`
--
ALTER TABLE `hospitalsignup`
  ADD PRIMARY KEY (`userName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `centernotifications`
--
ALTER TABLE `centernotifications`
  MODIFY `notificationID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `specialID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `hospitalemergency`
--
ALTER TABLE `hospitalemergency`
  MODIFY `emergencyID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
